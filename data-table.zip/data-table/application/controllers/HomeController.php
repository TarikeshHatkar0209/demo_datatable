<?php 
class HomeController extends CI_Controller {
    
    public function index()
    {
        # code...
        $this->load->view('home');
    }

}
?>
